#!/usr/bin/env python3
"""
Organizer 2.1 (organizer.py) - a configurable, cross-platform folder organizer (stdlib only).

Features
  * Rule-based sorting: extension, filename glob, regex, file size
  * Your own folders: send specific files (a project's README, .bat, .xml, .exe ...) to a
      folder of your choice instead of the common type folders - manage them with
      manage_folders.py (menu) or by editing "rules" in the config
  * Sub-folders inside each main folder, e.g. Images/PNG/2026-11 or Documents/Resumes
      - automatic: by extension, year, month, year-month, first letter, size
      - custom: nested "sub_rules" per rule (e.g. Documents -> Resumes, Invoices)
      - set globally, or override per rule
  * Safe conflict handling (rename / skip / overwrite) and duplicate detection
  * Ignores hidden files and in-progress downloads (.crdownload, .part, ...)
  * Waits until a file is "settled" (min age) so it never moves a file mid-download
  * Dry-run mode, undo of the last run, watch mode, JSON config, logging

Where it runs
  By default it organizes the folder you run it FROM (your current folder), so one
  copy of this script can serve any folder: cd into the folder, run the script.
  Use -s to point it at a different folder instead.
  Safety: it refuses system folders, asks for confirmation, and stops on project
  folders (.git, package.json, ...) unless you pass --force.

Quick start
  python organizer.py --init-config          # writes organizer_config.json
  python organizer.py --dry-run              # preview for the current folder
  python D:/tools/organizer.py              # organize the current folder
  python organizer.py -s ~/Downloads         # organize a specific folder
  python organizer.py --watch --interval 60  # keep running
  python organizer.py --undo                 # reverse the last run
  python organizer.py -s ~/Desktop -r        # include sub-folders too
  python organizer.py -y                     # skip the confirmation prompt
"""

import argparse
import contextlib
import errno
import fnmatch
import functools
import hashlib
import json
import logging
import logging.handlers
import os
import re
import shutil
import sys
import time
import uuid
from collections import Counter
from datetime import datetime
from pathlib import Path

__version__ = "2.1"

HISTORY_FILE = ".organizer_history.jsonl"   # legacy location (inside the organized folder)
SCRIPT_DIR = Path(__file__).resolve().parent
SKIP_DIR_NAMES = {"System Volume Information", "node_modules", "__pycache__", "venv", ".venv"}
# A folder counts as a "project" if it has any STRONG marker, or two or more WEAK ones.
# (A single downloaded Makefile or requirements.txt in Downloads is NOT a project.)
STRONG_MARKERS = [".git", ".hg", ".svn", "package.json", "pyproject.toml", "Cargo.toml",
                  "platformio.ini", "CMakeLists.txt", "pom.xml", "build.gradle"]
WEAK_MARKERS = ["Makefile", "requirements.txt", "setup.py"]
SYSTEM_DIRS_POSIX = ["/bin", "/boot", "/dev", "/etc", "/lib", "/lib64", "/proc", "/sbin",
                     "/sys", "/usr", "/var", "/System", "/Library", "/Applications"]
DEFAULT_CONFIG_NAME = "organizer_config.json"

DEFAULT_CONFIG = {
    "source": ".",                  # "." = the folder you run the script from
    "recursive": False,
    "min_age_seconds": 30,
    # Default sub-folders inside every main folder. Any combination, applied in order:
    # extension | year | month | year-month | first-letter | size   ([] = none)
    # A rule can override this with its own "subfolders" key.
    "subfolders": [],
    # Subject folders for the "topic" sub-folder mode: first topic with a matching word in the
    # file name wins. Files that match nothing stay at the level above (or go to topic_default).
    "topics": {
        "RTOS": ["rtos", "freertos", "zephyr"],
        "IoT": ["iot", "mqtt", "internet of things", "esp32"],
        "ARM": ["arm", "cortex", "thumb", "stm32"],
        "RISC-V": ["risc v", "riscv", "risc"],
        "Microcontrollers": ["microcontroller", "8051", "avr", "atmega"],
        "Resume": ["resume", "cv", "curriculum vitae"],
    },
    "topic_default": None,
    "on_conflict": "rename",         # rename | skip | overwrite
    "dedupe_identical": True,        # identical files go to duplicates_folder
    "duplicates_folder": "_Duplicates",
    "other_folder": "Other",         # set to null to leave unmatched files alone
    "ignore_hidden": True,
    "ignore_patterns": ["desktop.ini", "Thumbs.db", ".DS_Store", "*.lnk", "*password*.csv"],
    "partial_extensions": [".crdownload", ".part", ".tmp", ".download", ".partial", ".opdownload"],
    "rules": [
        {"name": "Screenshots", "patterns": ["Screenshot*", "Screen Shot*"], "extensions": [".png", ".jpg", ".jpeg", ".webp", ".bmp"],
         "dest": "Images/Screenshots"},
        {"name": "Images", "extensions": [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff", ".svg", ".heic", ".ico"],
         "dest": "Images", "subfolders": ["extension"]},
        {"name": "Videos", "extensions": [".mp4", ".mkv", ".mov", ".avi", ".wmv", ".flv", ".webm"], "dest": "Videos", "subfolders": ["extension"]},
        {"name": "Audio", "extensions": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"], "dest": "Audio", "subfolders": ["extension"]},
        {"name": "Build files", "patterns": ["Makefile", "GNUmakefile", "CMakeLists.txt", "*.mk", "*.cmake", "platformio.ini", "Dockerfile", "*.ld", "*.lds"],
         "dest": "Code/Build"},   # extension-less / special names; must stay above Documents
        {"name": "Documents", "extensions": [".pdf", ".docx", ".doc", ".pptx", ".ppt", ".odp", ".key", ".xlsx", ".xls", ".xlsm", ".csv", ".ods",
                        ".xml", ".txt", ".rtf", ".odt", ".md"],
         "dest": "Documents", "subfolders": ["extension", "topic"]},   # Documents/PDF, DOCX, PPTX, XLSX, CSV, XML ...
        {"name": "Ebooks", "extensions": [".epub", ".mobi", ".azw3"], "dest": "Ebooks"},
        {"name": "Archives", "extensions": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".tgz"], "dest": "Archives"},
        {"name": "Installers", "extensions": [".exe", ".msi", ".dmg", ".pkg", ".deb", ".rpm", ".apk", ".appimage"], "dest": "Installers"},
        {"name": "Disk images", "extensions": [".iso", ".img"], "dest": "Disk Images"},
        {"name": "Code", "extensions": [".py", ".c", ".cpp", ".h", ".hpp", ".java", ".js", ".ts", ".json", ".yaml", ".yml", ".sh", ".ino", ".v", ".vhd", ".asm", ".ipynb"],
         "dest": "Code", "subfolders": ["extension"]},
        {"name": "Fonts", "extensions": [".ttf", ".otf", ".woff", ".woff2"], "dest": "Fonts"},
        {"name": "Design", "extensions": [".psd", ".ai", ".fig", ".sketch", ".xd", ".dwg", ".stl"], "dest": "Design"},
        {"name": "Torrents", "extensions": [".torrent"], "dest": "Torrents"},
        {"name": "Large files", "min_size_mb": 1024, "dest": "Large Files"},
    ],
}

log = logging.getLogger("organizer")


# --------------------------------------------------------------------------- #
# History (kept in <Organizer folder>/history, never inside the folders you organize)
# --------------------------------------------------------------------------- #
@functools.lru_cache(maxsize=1)
def history_dir():
    """<folder of this script>/history, or ~/Organizer/history if that is not writable."""
    for candidate in (SCRIPT_DIR / "history", Path.home() / "Organizer" / "history"):
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / ".write_test"
            probe.write_text("ok")
            probe.unlink()
            return candidate
        except OSError:
            continue
    return None


def history_path(base):
    """One history file per organized folder, e.g. history/Downloads_1a2b3c4d.jsonl"""
    folder = history_dir()
    if folder is None:
        return base / HISTORY_FILE  # last resort
    tag = hashlib.sha1(str(base).lower().encode("utf-8")).hexdigest()[:8]
    name = re.sub(r"[^A-Za-z0-9]+", "_", base.name or "root").strip("_")[:40] or "root"
    return folder / f"{name}_{tag}.jsonl"


def migrate_legacy_history(base):
    """Move an old .organizer_history.jsonl out of the organized folder."""
    legacy, target = base / HISTORY_FILE, history_path(base)
    if not legacy.exists() or legacy == target:
        return
    try:
        old = legacy.read_text(encoding="utf-8")
        new = target.read_text(encoding="utf-8") if target.exists() else ""
        target.write_text(old + new, encoding="utf-8")  # old runs first, newest last
        legacy.unlink()
        log.info("moved old history file into %s", target.parent)
    except OSError as exc:
        log.warning("could not move old history file: %s", exc)


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
def find_config(explicit):
    """-c file > organizer_config.json in the target folder > next to the script."""
    if explicit:
        p = Path(explicit).expanduser()
        if not p.exists():
            sys.exit(f"Config file not found: {p}")
        return p, True
    for folder in (Path.cwd(), Path(__file__).resolve().parent):
        candidate = folder / DEFAULT_CONFIG_NAME
        if candidate.exists():
            return candidate, False
    return None, False


def load_config(explicit):
    """Returns (config, path of config used or None)."""
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))  # deep copy
    path, is_explicit = find_config(explicit)
    if path:
        with open(path, "r", encoding="utf-8") as fh:
            user = json.load(fh)
        if not is_explicit:
            user.pop("source", None)  # auto-found configs supply rules only, never the folder
        cfg.update(user)
    return cfg, path


def resolve_dest(base, dest):
    """Absolute / ~ paths are used as-is, relative ones live inside `base`."""
    d = Path(dest).expanduser()
    return d if d.is_absolute() else base / d


# --------------------------------------------------------------------------- #
# Matching
# --------------------------------------------------------------------------- #
def rule_matches(rule, path, size):
    name = path.name.lower()
    ext = "".join(path.suffixes[-1:]).lower()
    checks = []

    if "extensions" in rule:
        checks.append(ext in [e.lower() for e in rule["extensions"]])
    if "patterns" in rule:
        checks.append(any(fnmatch.fnmatch(name, p.lower()) for p in rule["patterns"]))
    if "regex" in rule:
        checks.append(re.search(rule["regex"], path.name, re.IGNORECASE) is not None)
    if "min_size_mb" in rule:
        checks.append(size >= rule["min_size_mb"] * 1024 * 1024)
    if "max_size_mb" in rule:
        checks.append(size <= rule["max_size_mb"] * 1024 * 1024)

    # all specified criteria must hold (AND); a rule with no criteria never matches
    return bool(checks) and all(checks)


SUBFOLDER_MODES = ["extension", "year", "month", "year-month", "first-letter", "size", "topic"]


def topic_parts(cfg, path):
    """Folder for the first subject in cfg["topics"] whose keyword appears in the file name.

    Case-insensitive; '_', '-', '.' and spaces count the same, and a keyword must not sit
    inside a longer word (so "arm" matches "ARM_Theory" but not "alarm").
    """
    text = re.sub(r"[^a-z0-9]+", " ", path.stem.lower())
    for topic, words in cfg.get("topics", {}).items():
        for word in words:
            word = re.sub(r"[^a-z0-9]+", " ", word.lower()).strip()
            if word and re.search(rf"(?<![a-z]){re.escape(word)}(?![a-z])", text):
                return [topic]
    default = cfg.get("topic_default")
    return [default] if default else []


def subfolder_parts(mode, path, size, cfg):
    """Return the folder name(s) a given sub-folder mode adds for this file."""
    mtime = datetime.fromtimestamp(path.stat().st_mtime)
    if mode == "extension":
        return [path.suffix.lstrip(".").upper() or "No Extension"]
    if mode == "year":
        return [f"{mtime:%Y}"]
    if mode == "month":
        return [f"{mtime:%Y-%m}"]
    if mode == "year-month":
        return [f"{mtime:%Y}", f"{mtime:%Y-%m}"]
    if mode == "first-letter":
        first = path.stem[:1].upper()
        return [first if first.isalpha() else "#"]
    if mode == "size":
        mb = size / (1024 * 1024)
        if mb < 1:
            return ["Small (under 1 MB)"]
        return ["Medium (1-100 MB)"] if mb < 100 else ["Large (100 MB+)"]
    if mode == "topic":
        return topic_parts(cfg, path)
    raise ValueError(f"Unknown subfolder mode: {mode}")


def add_subfolders(dest, modes, path, size, cfg):
    if isinstance(modes, str):
        modes = [modes]
    for mode in modes or []:
        for part in subfolder_parts(mode, path, size, cfg):
            dest = dest / part
    return dest


def pick_destination(cfg, base, path, size):
    """Return (final destination folder, label) or (None, None) to leave the file."""
    for rule in cfg["rules"]:
        if rule.get("enabled", True) is False or not rule_matches(rule, path, size):
            continue
        dest = resolve_dest(base, rule["dest"])
        label = rule["name"]
        for sub in rule.get("sub_rules", []):
            if rule_matches(sub, path, size):
                dest = dest / sub["dest"]
                label = f"{label}/{sub['name']}"
                break
        else:
            if rule.get("sub_default"):
                dest = dest / rule["sub_default"]
        modes = rule.get("subfolders", cfg.get("subfolders", []))
        return add_subfolders(dest, modes, path, size, cfg), label
    if cfg.get("other_folder"):
        dest = resolve_dest(base, cfg["other_folder"])
        return add_subfolders(dest, cfg.get("subfolders", []), path, size, cfg), "Other"
    return None, None


def validate_config(cfg):
    """Fail early on a typo in a subfolder mode instead of erroring per file."""
    if cfg.get("on_conflict") not in {"rename", "skip", "overwrite"}:
        sys.exit("on_conflict must be rename, skip, or overwrite")
    if cfg.get("min_age_seconds", 0) < 0:
        sys.exit("min_age_seconds cannot be negative")
    for number, rule in enumerate(cfg["rules"], 1):
        if not isinstance(rule, dict) or "name" not in rule or "dest" not in rule:
            sys.exit(f'Rule #{number} in the config needs both a "name" and a "dest".')
        for key in ("extensions", "patterns"):
            if key in rule and not isinstance(rule[key], list):
                sys.exit(f'Rule "{rule["name"]}": "{key}" must be a list, e.g. ["README.md", "build.bat"].')
        if "regex" in rule:
            try:
                re.compile(rule["regex"])
            except re.error as exc:
                sys.exit(f'Rule "{rule["name"]}": invalid regex ({exc}).')
        if not any(k in rule for k in ("extensions", "patterns", "regex", "min_size_mb", "max_size_mb")):
            log.warning('Rule "%s" has nothing to match on, so it will never be used.', rule["name"])
    topics = cfg.get("topics", {})
    if not isinstance(topics, dict) or any(not isinstance(v, list) for v in topics.values()):
        sys.exit('"topics" must look like {"RTOS": ["rtos", "freertos"], "IoT": ["iot", "mqtt"]}')
    all_modes = list(cfg.get("subfolders", []))
    for rule in cfg["rules"]:
        modes = rule.get("subfolders", [])
        all_modes += [modes] if isinstance(modes, str) else modes
    bad = [m for m in all_modes if m not in SUBFOLDER_MODES]
    if bad:
        sys.exit(f"Unknown subfolder mode(s): {', '.join(bad)}. Valid: {', '.join(SUBFOLDER_MODES)}")


# --------------------------------------------------------------------------- #
# File helpers
# --------------------------------------------------------------------------- #
def file_hash(path, chunk=1024 * 1024):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while block := fh.read(chunk):
            h.update(block)
    return h.hexdigest()


def identical(a, b):
    try:
        if a.stat().st_size != b.stat().st_size:
            return False
        return file_hash(a) == file_hash(b)
    except OSError:
        return False


def unique_path(path):
    if not path.exists():
        return path
    stem, suffix, n = path.stem, path.suffix, 1
    while True:
        candidate = path.with_name(f"{stem} ({n}){suffix}")
        if not candidate.exists():
            return candidate
        n += 1


def safe_move(src, dst):
    """Move a file without ever leaving a half-finished copy behind.

    shutil.move() silently falls back to copy+delete when a rename fails, which on Windows
    (file still locked by the browser/antivirus) can leave a duplicate. Here a rename that
    fails for any reason except "different drive" is simply raised.
    """
    src, dst = str(src), str(dst)
    try:
        os.rename(src, dst)
    except OSError as exc:
        if isinstance(exc, PermissionError) or exc.errno != errno.EXDEV:
            raise
        shutil.copy2(src, dst)                      # different drive: copy, verify, then delete
        if os.path.getsize(src) != os.path.getsize(dst):
            os.unlink(dst)
            raise OSError("copy verification failed; original left untouched")
        try:
            os.unlink(src)
        except OSError:
            os.unlink(dst)                          # could not delete the original: undo the copy
            raise


def is_hidden(path):
    if path.name.startswith("."):
        return True
    if sys.platform.startswith("win"):
        try:
            return bool(path.stat().st_file_attributes & 0x2)   # FILE_ATTRIBUTE_HIDDEN
        except (AttributeError, OSError):
            return False
    return False


def should_skip(cfg, path, protected):
    name = path.name
    if name == HISTORY_FILE or name == Path(__file__).name or name == DEFAULT_CONFIG_NAME:
        return "internal file"
    if cfg.get("ignore_hidden") and is_hidden(path):
        return "hidden"
    if path.suffix.lower() in [e.lower() for e in cfg["partial_extensions"]]:
        return "partial download"
    if any(fnmatch.fnmatch(name.lower(), p.lower()) for p in cfg["ignore_patterns"]):
        return "ignored pattern"
    if any(parent in protected for parent in path.parents):
        return "already organized"
    age = time.time() - path.stat().st_mtime
    if age < cfg["min_age_seconds"]:
        return "too new (may still be downloading)"
    return None


def iter_files(base, recursive, protected, ignore_hidden):
    if not recursive:
        try:
            for p in base.iterdir():
                if not p.is_symlink() and p.is_file():
                    yield p
        except OSError as exc:
            log.error("cannot read %s: %s", base, exc)
        return
    stack = [base]
    while stack:
        current = stack.pop()
        try:
            children = list(current.iterdir())
        except OSError as exc:
            log.error("cannot read %s: %s", current, exc)
            continue
        for p in children:
            if p.is_dir():
                if (p.is_symlink() or p in protected or p.name in SKIP_DIR_NAMES or p.name.startswith("$")
                        or (ignore_hidden and p.name.startswith("."))):
                    continue
                stack.append(p)
            elif not p.is_symlink() and p.is_file():
                yield p


def protected_dirs(cfg, base):
    dirs = {resolve_dest(base, r["dest"]).resolve() for r in cfg["rules"]}
    if cfg.get("other_folder"):
        dirs.add(resolve_dest(base, cfg["other_folder"]).resolve())
    dirs.add(resolve_dest(base, cfg["duplicates_folder"]).resolve())
    history = history_dir()
    if history is not None:
        dirs.add(history.resolve())
    # protect top-level of nested destinations too (e.g. Documents for Documents/PDFs)
    for d in list(dirs):
        try:
            rel = d.relative_to(base.resolve())
            dirs.add((base.resolve() / rel.parts[0]))
        except (ValueError, IndexError):
            pass
    if SCRIPT_DIR != base.resolve() and _inside(SCRIPT_DIR, base.resolve()):
        dirs.add(SCRIPT_DIR)  # the Organizer folder (script, config, history) is never touched
    return dirs


# --------------------------------------------------------------------------- #
# Core
# --------------------------------------------------------------------------- #
def organize(cfg, base, dry_run=False):
    if not dry_run:
        migrate_legacy_history(base)
    run_id = uuid.uuid4().hex[:8]
    protected = protected_dirs(cfg, base)
    history = []
    stats = {"moved": 0, "skipped": 0, "duplicates": 0, "errors": 0}
    skip_reasons = Counter()

    for path in sorted(iter_files(base, cfg["recursive"], protected, cfg["ignore_hidden"])):
        try:
            reason = should_skip(cfg, path, protected)
            if reason:
                log.debug("skip %s (%s)", path.name, reason)
                skip_reasons[reason] += 1
                stats["skipped"] += 1
                if reason.startswith("too new"):
                    log.info("waiting: %s (changed in the last %ds, still downloading?)",
                             path.name, cfg["min_age_seconds"])
                continue

            size = path.stat().st_size
            dest_dir, rule_name = pick_destination(cfg, base, path, size)
            if dest_dir is None:
                stats["skipped"] += 1
                continue
            target = dest_dir / path.name

            if target.exists() and identical(path, target):
                if cfg["dedupe_identical"]:
                    dest_dir = resolve_dest(base, cfg["duplicates_folder"])
                    target = unique_path(dest_dir / path.name)
                    rule_name = "Duplicate"
                    stats["duplicates"] += 1
                else:
                    stats["skipped"] += 1
                    continue
            elif target.exists():
                mode = cfg["on_conflict"]
                if mode == "skip":
                    log.info("conflict, skipping %s", path.name)
                    stats["skipped"] += 1
                    continue
                if mode == "rename":
                    target = unique_path(target)
                elif mode == "overwrite":
                    backup = unique_path(target.with_name(
                        f"{target.stem}.backup-{run_id}{target.suffix}"))
                    log.info("preserving overwritten file %s -> %s", target, backup)
                    if not dry_run:
                        backup.parent.mkdir(parents=True, exist_ok=True)
                        safe_move(target, backup)
                        history.append({"run": run_id, "src": str(target), "dst": str(backup),
                                        "time": datetime.now().isoformat(timespec="seconds")})

            log.info("%s%s -> %s  [%s]", "[dry-run] " if dry_run else "", path.name, target.parent, rule_name)
            if not dry_run:
                target.parent.mkdir(parents=True, exist_ok=True)
                safe_move(path, target)
                history.append({"run": run_id, "src": str(path), "dst": str(target),
                                "time": datetime.now().isoformat(timespec="seconds")})
            stats["moved"] += 1
        except PermissionError:
            log.warning("in use, will retry next run: %s", path.name)
            skip_reasons["in use"] += 1
            stats["skipped"] += 1
        except Exception as exc:  # keep going if a single file fails
            log.error("failed on %s: %s", path.name, exc)
            stats["errors"] += 1

    if history:
        try:
            with open(history_path(base), "a", encoding="utf-8") as fh:
                for entry in history:
                    fh.write(json.dumps(entry) + "\n")
        except OSError as exc:
            log.error("files were moved but the history could not be saved (undo unavailable): %s", exc)

    detail = f" [{', '.join(f'{n} {r}' for r, n in skip_reasons.most_common())}]" if skip_reasons else ""
    log.info("done: %d moved (%d duplicates), %d skipped%s, %d errors",
             stats["moved"], stats["duplicates"], stats["skipped"], detail, stats["errors"])
    return stats


@contextlib.contextmanager
def run_lock(base):
    """Stops two runs (e.g. the scheduled one and a manual one) from working on a folder at once.
    Yields False if another run is active."""
    lock = history_path(base).with_suffix(".lock")
    state = "free"
    for _ in range(2):
        try:
            os.close(os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY))
            state = "held"
            break
        except FileExistsError:
            try:
                if time.time() - lock.stat().st_mtime > 900:   # left behind by a crashed run
                    lock.unlink()
                    continue
            except OSError:
                pass
            state = "busy"
            break
        except OSError:
            break                                            # cannot lock: carry on without one
    try:
        yield state != "busy"
    finally:
        if state == "held":
            try:
                lock.unlink()
            except OSError:
                pass


def undo_last_run(base, dry_run=False):
    migrate_legacy_history(base)
    hist = history_path(base)
    if not hist.exists():
        log.info("nothing to undo")
        return
    entries = []
    for line in hist.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            entries.append(json.loads(line))
        except ValueError:
            log.warning("ignoring a damaged line in %s", hist.name)
    if not entries:
        log.info("nothing to undo")
        return

    last = entries[-1]["run"]
    last_run_indices = {i for i, entry in enumerate(entries) if entry["run"] == last}
    failed_indices = set()
    restored = 0

    for index in reversed(range(len(entries))):
        if index not in last_run_indices:
            continue
        e = entries[index]
        src, dst = Path(e["src"]), Path(e["dst"])
        if not dst.exists():
            log.warning("missing, cannot restore: %s", dst)
            failed_indices.add(index)
            continue
        restore = unique_path(src) if src.exists() else src
        log.info("%s%s -> %s", "[dry-run] " if dry_run else "", dst.name, restore.parent)
        if not dry_run:
            try:
                restore.parent.mkdir(parents=True, exist_ok=True)
                safe_move(dst, restore)
            except OSError as exc:
                log.error("could not restore %s: %s", dst, exc)
                failed_indices.add(index)
                continue
        restored += 1

    if not dry_run:
        remaining = [e for i, e in enumerate(entries) if i not in last_run_indices or i in failed_indices]
        try:
            hist.write_text("".join(json.dumps(e) + "\n" for e in remaining), encoding="utf-8")
        except OSError as exc:
            log.error("files were restored but history could not be updated: %s", exc)
    action = "would undo" if dry_run else "undid"
    log.info("%s run %s (%d files; %d could not be restored)",
             action, last, restored, len(failed_indices))


def cleanup_empty_dirs(base, cfg):
    protected = protected_dirs(cfg, base)
    for d in sorted((p for p in base.rglob("*") if p.is_dir()), reverse=True):
        if d.resolve() in protected:
            continue
        try:
            d.rmdir()  # only succeeds if empty
            log.info("removed empty folder %s", d)
        except OSError:
            pass


# --------------------------------------------------------------------------- #
# Safety
# --------------------------------------------------------------------------- #
def _inside(child, parent):
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def check_safe(base, recursive, force):
    """Stop before touching places where organizing could do damage."""
    # Hard stops: system locations (cannot be overridden)
    if sys.platform.startswith("win"):
        system_drive = Path(os.environ.get("SystemDrive", "C:") + "\\").resolve()
        system_dirs = [Path(os.environ[k]).resolve() for k in
                       ("SystemRoot", "ProgramFiles", "ProgramFiles(x86)", "ProgramData") if os.environ.get(k)]
        if base == system_drive or any(_inside(base, d) for d in system_dirs):
            sys.exit(f"Refusing to organize a system location: {base}")
    elif base == Path("/") or any(_inside(base, Path(d)) for d in SYSTEM_DIRS_POSIX):
        sys.exit(f"Refusing to organize a system location: {base}")

    if force:
        return
    # Soft stops: allowed with --force
    problems = []
    if base == Path.home().resolve():
        problems.append("this is your home folder")
    if recursive and base == Path(base.anchor):
        problems.append("recursive mode on a whole drive")
    strong = [m for m in STRONG_MARKERS if (base / m).exists()]
    weak = [m for m in WEAK_MARKERS if (base / m).exists()]
    markers = strong + (weak if (strong or len(weak) >= 2) else [])
    if markers:
        problems.append(f"this looks like a project folder (found {', '.join(markers)})")
    if problems:
        sys.exit(f"Stopped: {'; '.join(problems)}. Use --force if you are sure.")


def confirm(base, cfg, args):
    if args.yes or args.dry_run or sys.stdin is None or not sys.stdin.isatty():
        return
    extra = " including all sub-folders" if cfg["recursive"] else ""
    if input(f"Organize {base}{extra}? [y/N] ").strip().lower() not in ("y", "yes"):
        sys.exit("Cancelled.")


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description="Organize a folder automatically.")
    p.add_argument("-s", "--source", help="folder to organize (default: the folder you run the script from)")
    p.add_argument("-c", "--config", help="JSON config file (default: organizer_config.json in the target folder or next to the script)")
    p.add_argument("-r", "--recursive", action="store_true", help="also process sub-folders")
    p.add_argument("-n", "--dry-run", action="store_true", help="show what would happen, move nothing")
    p.add_argument("--subfolders", nargs="+", choices=SUBFOLDER_MODES + ["none"],
                   help="sub-folders inside each main folder, applied in order "
                        "(e.g. --subfolders extension year); overrides per-rule settings; 'none' disables")
    p.add_argument("--on-conflict", choices=["rename", "skip", "overwrite"])
    p.add_argument("--min-age", type=int, help="seconds a file must be untouched before moving")
    p.add_argument("--clean-empty", action="store_true", help="remove empty sub-folders afterwards")
    p.add_argument("-w", "--watch", action="store_true", help="keep running and organize repeatedly")
    p.add_argument("--interval", type=int, default=60, help="seconds between passes in watch mode")
    p.add_argument("--undo", action="store_true", help="reverse the last organizing run")
    p.add_argument("--init-config", action="store_true", help=f"write {DEFAULT_CONFIG_NAME} and exit")
    p.add_argument("--log-file", help="also write logs to this file")
    p.add_argument("--version", action="version", version=f"Organizer {__version__}")
    p.add_argument("--pause", action="store_true", help="wait for Enter before closing (used by the right-click menu)")
    p.add_argument("-y", "--yes", action="store_true", help="do not ask for confirmation")
    p.add_argument("--force", action="store_true", help="allow project folders, home folder, etc.")
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args()


def setup_logging(verbose, log_file):
    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter("%(asctime)s  %(message)s", "%H:%M:%S"))
    handlers = [console]
    file_format = logging.Formatter("%(asctime)s  %(levelname)-7s %(message)s", "%Y-%m-%d %H:%M:%S")
    folder = history_dir()
    if folder is not None:
        handlers.append(logging.handlers.RotatingFileHandler(
            folder / "organizer.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8"))
    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    for handler in handlers[1:]:
        handler.setFormatter(file_format)
    logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO, handlers=handlers)


def main():
    args = parse_args()
    setup_logging(args.verbose, args.log_file)
    if args.source and args.source.endswith('"'):
        # Windows quirk: -s "D:\" reaches us as  D:"  (backslash + quote); restore the folder
        args.source = args.source.rstrip('"') + "\\"

    if args.init_config:
        out = Path(DEFAULT_CONFIG_NAME)
        if out.exists():
            sys.exit(f"{out} already exists, not overwriting.")
        out.write_text(json.dumps(DEFAULT_CONFIG, indent=2), encoding="utf-8")
        print(f"Wrote {out}. Edit it, then run: python organizer.py -c {out}")
        return

    cfg, cfg_path = load_config(args.config)
    if cfg_path:
        log.info("using config: %s", cfg_path)
    if args.source:
        cfg["source"] = args.source
    if args.recursive:
        cfg["recursive"] = True
    if args.subfolders:
        cfg["subfolders"] = [] if args.subfolders == ["none"] else args.subfolders
        for rule in cfg["rules"]:       # the command line wins over per-rule settings
            rule.pop("subfolders", None)
    if args.on_conflict:
        cfg["on_conflict"] = args.on_conflict
    if args.min_age is not None:
        cfg["min_age_seconds"] = args.min_age

    validate_config(cfg)
    base = Path(cfg["source"]).expanduser().resolve()
    if not base.is_dir():
        sys.exit(f"Source folder does not exist: {base}")

    if args.undo:
        undo_last_run(base, args.dry_run)
        return

    check_safe(base, cfg["recursive"], args.force)
    confirm(base, cfg, args)
    log.info("organizing %s%s", base, " (dry run)" if args.dry_run else "")
    try:
        while True:
            guard = contextlib.nullcontext(True) if args.dry_run else run_lock(base)
            with guard as free:
                if not free:
                    log.info("another run is already working on this folder, skipping this one")
                else:
                    organize(cfg, base, args.dry_run)
                    if args.clean_empty and not args.dry_run:
                        cleanup_empty_dirs(base, cfg)
            if not args.watch:
                break
            time.sleep(args.interval)
    except KeyboardInterrupt:
        log.info("stopped")


def _wait_for_enter():
    if sys.stdin is not None and sys.stdin.isatty():
        try:
            input("\nPress Enter to close this window...")
        except EOFError:
            pass


if __name__ == "__main__":
    pause = "--pause" in sys.argv
    try:
        main()
    except SystemExit as exc:
        code = exc.code
        if isinstance(code, str):
            print(code, file=sys.stderr)
            code = 1
        if pause:
            _wait_for_enter()
        sys.exit(code)
    if pause:
        _wait_for_enter()
